# GIF TO JPG FRAMES CONVERTER

Version: 1.0.0

## ABOUT THE SOFTWARE

GIF to JPG Frames Converter is a simple Windows desktop application that extracts individual frames from animated GIF files and saves them as separate JPG images.

## FEATURES

- Extract all frames from animated GIF files.
- Convert GIF frames into JPG images.
- Automatically create a separate output folder.
- Keep the original GIF file unchanged.
- Simple graphical user interface.
- Local processing on your computer.

## SYSTEM REQUIREMENTS

- Windows 10 or later
- Python 3
- Pillow Python library

## INSTALLATION

1. Install Python 3.
2. Open Command Prompt inside the software folder.
3. Run this command:

   py -m pip install -r requirements.txt

## HOW TO USE

1. Open GIF_to_JPG_Frames.py.
2. Select an animated GIF file.
3. Start the conversion.
4. Wait for the conversion to finish.
5. Open the output folder.
6. Your JPG frames will be available there.

## OUTPUT EXAMPLE

GIF_to_JPG_Frames/
    frame_0001.jpg
    frame_0002.jpg
    frame_0003.jpg

## PRIVACY

The software processes files locally on your computer. GIF files are not uploaded to a remote server by this application.

## IMPORTANT

JPG is a still-image format. Therefore, the animated GIF is converted into multiple individual JPG images.

## SUPPORT

Product: GIF to JPG Frames Converter
Publisher: ClipForge
Version: 1.0.0