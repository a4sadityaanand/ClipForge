
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageSequence
import os
import threading


# ==========================================================
# CLIPFORGE - GIF TO JPG FRAMES CONVERTER
# ==========================================================

def choose_output_folder(input_file):

    folder = os.path.dirname(input_file)
    name = os.path.splitext(
        os.path.basename(input_file)
    )[0]

    base_folder = os.path.join(
        folder,
        name + "_JPG_Frames"
    )

    output_folder = base_folder
    counter = 2

    # Existing folder ko overwrite nahi karenge
    while os.path.exists(output_folder):

        output_folder = (
            base_folder + "_" + str(counter)
        )

        counter += 1

    return output_folder


def convert_gif(input_file):

    output_folder = choose_output_folder(
        input_file
    )

    os.makedirs(
        output_folder,
        exist_ok=True
    )

    try:

        with Image.open(input_file) as gif:

            total_frames = getattr(
                gif,
                "n_frames",
                1
            )

            for index, frame in enumerate(
                ImageSequence.Iterator(gif),
                start=1
            ):

                # Frame ko RGB mein convert karna
                # JPG transparency support nahi karta.
                jpg_frame = frame.convert("RGB")

                output_file = os.path.join(
                    output_folder,
                    f"frame_{index:04d}.jpg"
                )

                jpg_frame.save(
                    output_file,
                    "JPEG",
                    quality=95,
                    optimize=True
                )

                progress = (
                    index / total_frames
                ) * 100

                root.after(
                    0,
                    update_progress,
                    progress,
                    index,
                    total_frames
                )

        root.after(
            0,
            conversion_complete,
            output_folder,
            total_frames
        )

    except Exception as error:

        root.after(
            0,
            conversion_error,
            str(error)
        )


def update_progress(
    progress,
    current,
    total
):

    progress_bar["value"] = progress

    status_label.config(
        text=(
            f"Processing: {current}/{total} "
            f"frames ({progress:.1f}%)"
        )
    )


def conversion_complete(
    output_folder,
    total_frames
):

    convert_button.config(
        state="normal"
    )

    progress_bar["value"] = 100

    status_label.config(
        text="Conversion completed!"
    )

    messagebox.showinfo(
        "ClipForge - Complete",
        "GIF successfully converted!\n\n"
        f"Total Frames: {total_frames}\n\n"
        "JPG Images Folder:\n"
        + output_folder
    )

    open_folder_button.config(
        state="normal"
    )

    global last_output_folder
    last_output_folder = output_folder


def conversion_error(error):

    convert_button.config(
        state="normal"
    )

    status_label.config(
        text="Conversion failed!"
    )

    messagebox.showerror(
        "Conversion Error",
        error
    )


def start_conversion():

    input_file = filedialog.askopenfilename(
        title="Animated GIF Select Karo",
        filetypes=[
            ("GIF Files", "*.gif"),
            ("All Files", "*.*")
        ]
    )

    if not input_file:
        return

    convert_button.config(
        state="disabled"
    )

    open_folder_button.config(
        state="disabled"
    )

    progress_bar["value"] = 0

    status_label.config(
        text="Starting conversion..."
    )

    thread = threading.Thread(
        target=convert_gif,
        args=(input_file,),
        daemon=True
    )

    thread.start()


def open_output_folder():

    if (
        last_output_folder
        and os.path.isdir(last_output_folder)
    ):

        os.startfile(last_output_folder)


# ==========================================================
# WINDOW
# ==========================================================

root = tk.Tk()

root.title(
    "ClipForge - GIF to JPG Frames"
)

root.geometry(
    "550x410"
)

root.resizable(
    False,
    False
)

root.configure(
    bg="#080d0b"
)

last_output_folder = None


# ==========================================================
# TITLE
# ==========================================================

title_label = tk.Label(
    root,
    text="GIF → JPG FRAMES",
    font=("Arial", 22, "bold"),
    fg="#7cff6b",
    bg="#080d0b"
)

title_label.pack(
    pady=(30, 8)
)


subtitle = tk.Label(
    root,
    text="Convert every GIF frame into a JPG image",
    font=("Arial", 10),
    fg="#9bb0a1",
    bg="#080d0b"
)

subtitle.pack(
    pady=5
)


# ==========================================================
# INFORMATION
# ==========================================================

info = tk.Label(
    root,
    text=(
        "• Extract all animation frames\n"
        "• Save as separate JPG images\n"
        "• Automatic frame numbering\n"
        "• Original GIF remains unchanged"
    ),
    font=("Arial", 11),
    fg="#edf7ef",
    bg="#101a14",
    justify="left",
    padx=25,
    pady=18
)

info.pack(
    pady=20
)


# ==========================================================
# CONVERT BUTTON
# ==========================================================

convert_button = tk.Button(
    root,
    text="SELECT GIF & CONVERT",
    command=start_conversion,
    font=("Arial", 12, "bold"),
    bg="#7cff6b",
    fg="#071008",
    activebackground="#5cebd2",
    width=27,
    height=2,
    relief="flat",
    cursor="hand2"
)

convert_button.pack(
    pady=10
)


# ==========================================================
# PROGRESS
# ==========================================================

progress_bar = ttk.Progressbar(
    root,
    length=380,
    mode="determinate",
    maximum=100
)

progress_bar.pack(
    pady=10
)


status_label = tk.Label(
    root,
    text="Ready",
    font=("Arial", 10),
    fg="#7cff6b",
    bg="#080d0b"
)

status_label.pack(
    pady=5
)


# ==========================================================
# OPEN OUTPUT FOLDER
# ==========================================================

open_folder_button = tk.Button(
    root,
    text="OPEN JPG IMAGES FOLDER",
    command=open_output_folder,
    font=("Arial", 10, "bold"),
    bg="#101a14",
    fg="#7cff6b",
    activebackground="#24402e",
    width=27,
    state="disabled",
    relief="flat",
    cursor="hand2"
)

open_folder_button.pack(
    pady=8
)


# ==========================================================
# FOOTER
# ==========================================================

footer = tk.Label(
    root,
    text="ClipForge Python Tools © 2026",
    font=("Arial", 9),
    fg="#718779",
    bg="#080d0b"
)

footer.pack(
    side="bottom",
    pady=12
)


root.mainloop()
