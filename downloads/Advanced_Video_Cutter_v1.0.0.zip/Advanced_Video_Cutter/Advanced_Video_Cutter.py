import os, shutil, subprocess, threading, tkinter as tk
from tkinter import filedialog, messagebox, ttk
try:
    import cv2
    from PIL import Image, ImageTk
except ImportError as e:
    r=tk.Tk(); r.withdraw()
    messagebox.showerror("Missing libraries", "Run in CMD:\npython -m pip install opencv-python pillow\n\n"+str(e))
    raise SystemExit(1)

BG="#10141c"; PANEL="#1a2230"; FG="#f3f6fb"; GREEN="#35c7a5"; ORANGE="#ffb454"
def tm(s):
    s=max(0,float(s)); m=int(s//60); sec=s%60
    return f"{m:02d}:{sec:05.2f}" if s<3600 else f"{int(s//3600):02d}:{m%60:02d}:{sec:05.2f}"
def ffmpeg_path():
    p=shutil.which("ffmpeg")
    if p: return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception: return None

class App:
 def __init__(self,root):
    self.r=root; root.title("Advanced Video Cutter"); root.geometry("1000x720"); root.minsize(780,560); root.configure(bg=BG)
    self.cap=None; self.path=None; self.duration=0; self.fps=25; self.pos=0; self.start=0; self.end=0; self.playing=False; self.photo=None; self.drag=None; self.exporting=False
    top=tk.Frame(root,bg=BG); top.pack(fill="x",padx=16,pady=12)
    tk.Label(top,text="✂ ADVANCED VIDEO CUTTER",bg=BG,fg=FG,font=("Segoe UI",18,"bold")).pack(side="left")
    tk.Label(top,text="OFFLINE • PRIVATE • MP4",bg=BG,fg=GREEN,font=("Segoe UI",9,"bold")).pack(side="right")
    bar=tk.Frame(root,bg=PANEL,padx=8,pady=8); bar.pack(fill="x",padx=16)
    self.btn(bar,"＋ Open Video",self.open,GREEN,"#062016").pack(side="left",padx=3)
    self.btn(bar,"▶ / Pause",self.toggle).pack(side="left",padx=3)
    self.btn(bar,"◀ Frame",lambda:self.seek(self.pos-1/max(self.fps,1))).pack(side="left",padx=3)
    self.btn(bar,"Frame ▶",lambda:self.seek(self.pos+1/max(self.fps,1))).pack(side="left",padx=3)
    self.btn(bar,"Set Start",self.setstart).pack(side="left",padx=(12,3))
    self.btn(bar,"Set End",self.setend).pack(side="left",padx=3)
    self.export=self.btn(bar,"Export MP4",self.export_video,ORANGE,"#271907"); self.export.pack(side="right",padx=3)
    self.preview=tk.Frame(root,bg="#070a10"); self.preview.pack(fill="both",expand=True,padx=16,pady=10)
    self.view=tk.Label(self.preview,text="Open a video to begin\n\nMP4 • MOV • MKV • AVI",bg="#070a10",fg="#a8b4c7",font=("Segoe UI",16))
    self.view.pack(fill="both",expand=True)
    info=tk.Frame(root,bg=BG); info.pack(fill="x",padx=20)
    self.filename=tk.Label(info,text="No video loaded",bg=BG,fg=FG,anchor="w"); self.filename.pack(side="left",fill="x",expand=True)
    self.clock=tk.Label(info,text="00:00.00 / 00:00.00",bg=BG,fg=GREEN,font=("Consolas",10,"bold")); self.clock.pack(side="right")
    tl=tk.Frame(root,bg=PANEL,padx=12,pady=8); tl.pack(fill="x",padx=16,pady=8)
    tk.Label(tl,text="TIMELINE — drag green START and orange END handles",bg=PANEL,fg=FG,font=("Segoe UI",10,"bold")).pack(anchor="w")
    self.canvas=tk.Canvas(tl,height=70,bg=PANEL,highlightthickness=0); self.canvas.pack(fill="x")
    self.canvas.bind("<Configure>",lambda e:self.draw()); self.canvas.bind("<Button-1>",self.click); self.canvas.bind("<B1-Motion>",self.dragto); self.canvas.bind("<ButtonRelease-1>",lambda e:setattr(self,"drag",None))
    row=tk.Frame(root,bg=BG); row.pack(fill="x",padx=20,pady=(0,4))
    self.slabel=tk.Label(row,text="START 00:00.00",bg=BG,fg=GREEN,font=("Consolas",10,"bold")); self.slabel.pack(side="left")
    self.selected=tk.Label(row,text="Selected: 00:00.00",bg=BG,fg=FG); self.selected.pack(side="left",expand=True)
    self.elabel=tk.Label(row,text="END 00:00.00",bg=BG,fg=ORANGE,font=("Consolas",10,"bold")); self.elabel.pack(side="right")
    self.status=tk.Label(root,text="Ready • files stay on this PC",bg=BG,fg="#a8b4c7",anchor="w"); self.status.pack(fill="x",padx=20,pady=(4,12))
    root.protocol("WM_DELETE_WINDOW",self.close); self.draw()
 def btn(self,p,t,cmd,bg="#2a3546",fg=FG):
    return tk.Button(p,text=t,command=cmd,bg=bg,fg=fg,activebackground="#42536b",activeforeground=FG,relief="flat",bd=0,padx=10,pady=7,font=("Segoe UI",9,"bold"),cursor="hand2")
 def open(self):
    p=filedialog.askopenfilename(filetypes=[("Video files","*.mp4 *.mov *.mkv *.avi *.webm *.m4v"),("All files","*.*")])
    if not p:return
    c=cv2.VideoCapture(p); fps=c.get(cv2.CAP_PROP_FPS) or 25; frames=c.get(cv2.CAP_PROP_FRAME_COUNT); dur=frames/fps if fps>0 else 0
    if not c.isOpened() or dur<=0:
        c.release(); messagebox.showerror("Open failed","This video could not be read."); return
    if self.cap:self.cap.release()
    self.cap=c; self.path=p; self.fps=fps; self.duration=dur; self.pos=0; self.start=0; self.end=dur; self.playing=False
    self.filename.config(text=os.path.basename(p)); self.status.config(text=f"Loaded • {dur:.2f} sec • {fps:.2f} FPS"); self.seek(0)
 def seek(self,s):
    if not self.cap:return
    self.pos=max(0,min(float(s),max(0,self.duration-.001))); self.cap.set(cv2.CAP_PROP_POS_MSEC,self.pos*1000); ok,fr=self.cap.read()
    if ok:
        rgb=cv2.cvtColor(fr,cv2.COLOR_BGR2RGB); im=Image.fromarray(rgb); im.thumbnail((max(320,self.preview.winfo_width()-20),max(220,self.preview.winfo_height()-20)))
        self.photo=ImageTk.PhotoImage(im); self.view.config(image=self.photo,text="")
    self.draw()
 def toggle(self):
    if not self.cap: messagebox.showinfo("Open video","Click Open Video first."); return
    self.playing=not self.playing; self.status.config(text="Playing preview…" if self.playing else "Paused")
    if self.playing:self.tick()
 def tick(self):
    if not self.playing or not self.cap:return
    if self.pos+1/max(self.fps,1)>=self.duration:
        self.playing=False; self.seek(0); return
    self.seek(self.pos+1/max(self.fps,1)); self.r.after(max(12,int(1000/min(max(self.fps,1),60))),self.tick)
 def setstart(self):
    if self.cap:
        self.start=min(self.pos,max(0,self.end-.05)); self.draw()
 def setend(self):
    if self.cap:
        self.end=max(self.pos,min(self.duration,self.start+.05)); self.draw()
 def x(self,t):
    w=max(1,self.canvas.winfo_width()); return 20+(w-40)*(t/self.duration if self.duration else 0)
 def xt(self,x):
    w=max(1,self.canvas.winfo_width()); return max(0,min(1,(x-20)/max(1,w-40)))*self.duration
 def draw(self):
    if not hasattr(self,"canvas"):return
    c=self.canvas; c.delete("all"); w=max(1,c.winfo_width()); l=20; rr=w-20; y=32
    c.create_line(l,y,rr,y,fill="#3b4658",width=14,capstyle="round")
    if self.duration:
        sx=self.x(self.start); ex=self.x(self.end); px=self.x(self.pos)
        c.create_line(sx,y,ex,y,fill="#285f57",width=14,capstyle="round")
        c.create_line(sx,y,ex,y,fill=GREEN,width=4,capstyle="round")
        c.create_line(px,14,px,52,fill=FG,width=2)
        c.create_polygon(sx,14,sx-7,3,sx+7,3,fill=GREEN); c.create_polygon(ex,14,ex-7,3,ex+7,3,fill=ORANGE)
        c.create_text(l,62,text=tm(0),fill="#a8b4c7",anchor="w",font=("Consolas",8))
        c.create_text(rr,62,text=tm(self.duration),fill="#a8b4c7",anchor="e",font=("Consolas",8))
    else:c.create_text(w//2,y,text="Open a video to show timeline",fill="#a8b4c7")
    self.slabel.config(text="START "+tm(self.start)); self.elabel.config(text="END "+tm(self.end))
    self.selected.config(text="Selected: "+tm(max(0,self.end-self.start)))
    self.clock.config(text=tm(self.pos)+" / "+tm(self.duration))
 def click(self,e):
    if not self.duration:return
    if abs(e.x-self.x(self.start))<14:self.drag="start"
    elif abs(e.x-self.x(self.end))<14:self.drag="end"
    else:self.drag="play"; self.seek(self.xt(e.x))
 def dragto(self,e):
    if not self.drag or not self.duration:return
    t=self.xt(e.x)
    if self.drag=="start":self.start=min(t,max(0,self.end-.05))
    elif self.drag=="end":self.end=max(t,min(self.duration,self.start+.05))
    else:self.seek(t)
    self.draw()
 def export_video(self):
    if not self.path:messagebox.showinfo("Open video","Open a video first."); return
    if self.exporting:return
    a=max(0,self.start); b=min(self.duration,self.end)
    if b-a<.05:messagebox.showerror("Invalid selection","Drag START and END apart."); return
    ff=ffmpeg_path()
    if not ff:
        messagebox.showinfo("FFmpeg required","For MP4 export, open CMD and run:\n\npython -m pip install imageio-ffmpeg\n\nThen close and reopen this app. Internet is needed only for this one-time installation.")
        return
    out=filedialog.asksaveasfilename(defaultextension=".mp4",initialfile=os.path.splitext(os.path.basename(self.path))[0]+"_cut.mp4",filetypes=[("MP4 video","*.mp4")])
    if not out:return
    if os.path.abspath(out)==os.path.abspath(self.path):messagebox.showerror("Choose another name","Save to a new filename to preserve the original."); return
    self.exporting=True; self.export.config(state="disabled"); self.status.config(text="Exporting MP4… please wait")
    def work():
        cmd=[ff,"-y","-ss",f"{a:.3f}","-i",self.path,"-t",f"{b-a:.3f}","-map","0:v:0","-map","0:a?","-c:v","libx264","-preset","fast","-crf","20","-c:a","aac","-b:a","192k","-movflags","+faststart",out]
        try:
            p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            err=(p.stderr or "Export failed")[-1600:] if p.returncode else None
            self.r.after(0,lambda:self.done(out if not err else None,err))
        except Exception as e:self.r.after(0,lambda:self.done(None,str(e)))
    threading.Thread(target=work,daemon=True).start()
 def done(self,out,err):
    self.exporting=False; self.export.config(state="normal")
    if err:self.status.config(text="Export failed"); messagebox.showerror("Export failed",err)
    else:self.status.config(text="Export complete • "+os.path.basename(out)); messagebox.showinfo("Export complete","Saved video to:\n\n"+out)
 def close(self):
    self.playing=False
    if self.cap:self.cap.release()
    self.r.destroy()

if __name__=="__main__":
    root=tk.Tk(); app=App(root); root.mainloop()
