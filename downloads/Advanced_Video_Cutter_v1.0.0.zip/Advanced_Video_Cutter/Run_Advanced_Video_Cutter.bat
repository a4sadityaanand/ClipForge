@echo off
title Advanced Video Cutter
cd /d "%~dp0"
python -u "Advanced_Video_Cutter.py"
if errorlevel 1 (
  echo.
  echo App error shown above. Take a screenshot and send it to ChatGPT.
  pause
)
