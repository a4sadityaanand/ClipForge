ADVANCED VIDEO CUTTER - WINDOWS

1. Extract this ZIP to a folder.
2. Double-click Run_Advanced_Video_Cutter.bat.
3. If libraries are missing, open CMD and run:
   python -m pip install opencv-python pillow
4. For MP4 export, if the app asks for FFmpeg helper, run:
   python -m pip install imageio-ffmpeg
   Then close and reopen the app.

Features: local video preview, play/pause, frame stepping, draggable START/END timeline handles, set start/end at current preview position, MP4 export with audio if present.

The app does not upload your videos. Initial package installation may require internet; after setup, cutting and export can work offline.
