# Video to DP GIF Converter

Version: 1.0.0

## About
Convert video files into animated 1:1 square GIFs.

## Features
- Full video fit inside a square frame.
- No video cropping.
- Automatic resolution selection.
- Automatic FPS selection.
- Target GIF size: 10 MB or less.
- Up to 256 colors.
- Animated GIF output.

## Supported video formats
MP4, MKV, AVI, MOV, WEBM and 3GP.

## Requirements
- Windows 10 or later
- Python 3
- FFmpeg
- FFprobe

FFmpeg and FFprobe must be installed and accessible through Windows PATH.

## How to Use
1. Install Python and FFmpeg.
2. Open the extracted product folder.
3. Run GifHD.py using Python.
4. Click SELECT VIDEO & MAKE GIF.
5. Select a video.
6. Wait for conversion.
7. Find the generated GIF in the original video's folder.

## Important
The 10 MB size is a target. Some long or complex videos may not convert within this limit.

## Privacy
Video processing takes place locally on your computer. This tool does not upload your video to a website.

## Product
ClipForge - Python Tools Center