import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import os
import threading


# ============================================================
# VIDEO → DP GIF
# FULL VIDEO PRESERVE + 1:1 SQUARE
# TARGET SIZE: ~10 MB
# ============================================================

def run_ffmpeg(command):

    return subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )


def get_duration(input_file):

    command = [
        "ffprobe",
        "-v", "error",
        "-show_entries",
        "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        input_file
    ]

    result = run_ffmpeg(command)

    if result.returncode != 0:
        raise Exception(result.stderr)

    return float(result.stdout.strip())


def make_gif(input_file, output_file, size, fps):

    # --------------------------------------------------------
    # FULL VIDEO FIT INTO SQUARE
    #
    # Crop nahi hoga.
    #
    # Video square ke andar maximum size mein fit hoga.
    # Baaki area black rahega.
    # --------------------------------------------------------

    scale_pad = (
        f"scale={size}:{size}:"
        "force_original_aspect_ratio=decrease,"
        f"pad={size}:{size}:(ow-iw)/2:(oh-ih)/2"
    )

    # Palette + GIF in ONE command
    filter_complex = (
        f"[0:v]"
        f"{scale_pad},"
        f"fps={fps},"
        "split[a][b];"
        "[a]palettegen="
        "max_colors=256:"
        "stats_mode=diff[p];"
        "[b][p]paletteuse="
        "dither=sierra2_4a"
        "[v]"
    )

    command = [
        "ffmpeg",
        "-y",

        "-i",
        input_file,

        "-filter_complex",
        filter_complex,

        "-map",
        "[v]",

        "-an",

        "-loop",
        "0",

        output_file
    ]

    result = run_ffmpeg(command)

    return result


# ============================================================
# MAIN CONVERSION
# ============================================================

def convert_video():

    input_file = filedialog.askopenfilename(
        title="Video Select Karo",
        filetypes=[
            ("Video Files",
             "*.mp4 *.mkv *.avi *.mov *.webm *.3gp"),
            ("All Files", "*.*")
        ]
    )

    if not input_file:
        return

    folder = os.path.dirname(input_file)

    name = os.path.splitext(
        os.path.basename(input_file)
    )[0]

    convert_button.config(
        state="disabled"
    )

    try:

        status_label.config(
            text="Video duration check..."
        )

        root.update_idletasks()

        duration = get_duration(
            input_file
        )

        # ====================================================
        # TARGET
        # ====================================================

        TARGET_MB = 10.0

        # Starting settings
        sizes = [
            720,
            640,
            576,
            512,
            480
        ]

        fps_values = [
            15,
            12,
            10,
            8
        ]

        success = False

        best_file = None
        best_size = None

        # ====================================================
        # AUTOMATIC SIZE SEARCH
        # ====================================================

        attempt = 0

        for size in sizes:

            for fps in fps_values:

                attempt += 1

                status_label.config(
                    text=
                    f"Trying {size}×{size} | "
                    f"{fps} FPS..."
                )

                root.update_idletasks()

                temp_file = os.path.join(
                    folder,
                    "__dp_gif_test.gif"
                )

                result = make_gif(
                    input_file,
                    temp_file,
                    size,
                    fps
                )

                if result.returncode != 0:

                    if os.path.exists(temp_file):
                        os.remove(temp_file)

                    continue

                if not os.path.exists(
                    temp_file
                ):
                    continue

                file_size = (
                    os.path.getsize(temp_file)
                    / (1024 * 1024)
                )

                # ------------------------------------------------
                # Agar 10 MB ke andar hai,
                # isi ko best result maanenge.
                # ------------------------------------------------

                if file_size <= TARGET_MB:

                    best_file = temp_file
                    best_size = file_size
                    best_resolution = size
                    best_fps = fps

                    success = True

                    break

                # Too big → delete
                os.remove(temp_file)

            if success:
                break

        # ====================================================
        # RESULT
        # ====================================================

        if not success:

            raise Exception(
                "10 MB ke andar GIF nahi ban saki.\n\n"
                "Video bahut long hai ya frames bahut complex hain."
            )

        output_file = os.path.join(
            folder,
            name +
            f"_DP_{best_resolution}x"
            f"{best_resolution}.gif"
        )

        # Existing output delete
        if os.path.exists(output_file):
            os.remove(output_file)

        os.rename(
            best_file,
            output_file
        )

        status_label.config(
            text=
            f"Done! {best_size:.2f} MB"
        )

        messagebox.showinfo(
            "GIF Ready!",
            "DP GIF Ready! 🎉\n\n"
            f"Resolution: "
            f"{best_resolution}×{best_resolution}\n"
            f"FPS: {best_fps}\n"
            f"Size: {best_size:.2f} MB\n\n"
            "Crop: NONE\n"
            "Full video preserved\n"
            "1:1 Square\n\n"
            "File:\n"
            + output_file
        )

    except FileNotFoundError:

        messagebox.showerror(
            "FFmpeg Error",
            "FFmpeg / FFprobe nahi mila.\n\n"
            "CMD mein check karo:\n"
            "ffmpeg -version"
        )

        status_label.config(
            text="FFmpeg Missing!"
        )

    except Exception as e:

        status_label.config(
            text="Error!"
        )

        messagebox.showerror(
            "Error",
            str(e)
        )

    finally:

        convert_button.config(
            state="normal"
        )


# ============================================================
# THREAD
# ============================================================

def start_conversion():

    thread = threading.Thread(
        target=convert_video,
        daemon=True
    )

    thread.start()


# ============================================================
# WINDOW
# ============================================================

root = tk.Tk()

root.title(
    "Video → DP GIF 10MB"
)

root.geometry(
    "560x410"
)

root.resizable(
    False,
    False
)


title_label = tk.Label(
    root,
    text="Video → DP GIF",
    font=("Arial", 21, "bold")
)

title_label.pack(
    pady=25
)


settings_label = tk.Label(
    root,
    text=
    "FULL VIDEO → 1:1 SQUARE\n\n"
    "Crop        : NONE\n"
    "Resolution  : Automatic\n"
    "FPS         : Automatic\n"
    "Target Size : ≤ 10 MB\n"
    "Colors      : 256\n"
    "Animation   : ON",
    font=("Arial", 11)
)

settings_label.pack(
    pady=5
)


convert_button = tk.Button(
    root,
    text="SELECT VIDEO & MAKE GIF",
    command=start_conversion,
    font=("Arial", 12, "bold"),
    width=32,
    height=2
)

convert_button.pack(
    pady=30
)


status_label = tk.Label(
    root,
    text="Ready",
    font=("Arial", 10)
)

status_label.pack()


root.mainloop()