OFFLINE SHORTS VIDEO EDITOR (Windows)
======================================

Features:
- Merge multiple videos into one MP4
- Center crop to 9:16 Shorts, 1:1 square, or 16:9 landscape
- Add a music/audio file, set volume, optionally mix with original audio
- Change speed from 1.0x to 2.5x
- Media is processed locally; this app does not upload files

REQUIREMENT: FFmpeg
-------------------
Install FFmpeg once while online:
1. Open https://ffmpeg.org/download.html and choose a Windows build.
2. Extract the downloaded archive.
3. Find ffmpeg.exe inside its bin folder.
4. Add that bin folder to Windows PATH, OR copy ffmpeg.exe beside OfflineShortsEditor.py.
5. Open Command Prompt and run: ffmpeg -version
   If version details appear, FFmpeg is ready.

RUN
---
Python 3 is required. Open this folder in File Explorer and double-click OfflineShortsEditor.py,
or run: python OfflineShortsEditor.py

Notes:
- Output uses MP4/H.264/AAC.
- Merge re-encodes clips and can take some time.
- Crop is center crop and may cut off things near the edges.
- Use only music you own or have permission to use.
- This is a starter desktop app, not an installer/EXE yet.
