
import os
import shutil
import subprocess
import threading
import tempfile
import tkinter as tk

from tkinter import ttk, filedialog, messagebox


APP_NAME = "Offline Shorts Editor"


def find_ffmpeg():
    return shutil.which("ffmpeg")


def find_ffprobe():
    return shutil.which("ffprobe")


def run_command(command):
    result = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
    )

    if result.returncode != 0:
        error = result.stderr[-3500:] if result.stderr else "Unknown error"
        raise RuntimeError(error)

    return result


def has_audio(path):
    ffprobe = find_ffprobe()

    if not ffprobe:
        return True

    result = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-select_streams", "a",
            "-show_entries", "stream=codec_type",
            "-of", "csv=p=0",
            path
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
    )

    return bool(result.stdout.strip())


def audio_speed_filter(speed):
    filters = []

    # atempo filters are chained to support different speeds.
    remaining = float(speed)

    while remaining > 2.0:
        filters.append("atempo=2.0")
        remaining /= 2.0

    while remaining < 0.5:
        filters.append("atempo=0.5")
        remaining /= 0.5

    filters.append(f"atempo={remaining:.6f}")

    return ",".join(filters)


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.geometry("780x590")
        self.root.minsize(680, 500)

        self.root.configure(bg="#f1f3f6")

        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.style.configure(
            "TNotebook.Tab",
            padding=(16, 9),
            font=("Segoe UI", 10, "bold")
        )
        self.style.configure(
            "TButton",
            padding=7,
            font=("Segoe UI", 10)
        )
        self.style.configure(
            "TLabel",
            font=("Segoe UI", 10)
        )

        header = tk.Label(
            self.root,
            text="OFFLINE SHORTS EDITOR",
            font=("Segoe UI", 18, "bold"),
            bg="#f1f3f6",
            fg="#172554"
        )
        header.pack(pady=(12, 2))

        tk.Label(
            self.root,
            text="Merge  |  Fit Video  |  Background Music  |  Speed",
            font=("Segoe UI", 10),
            bg="#f1f3f6",
            fg="#475569"
        ).pack(pady=(0, 10))

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(
            fill="both",
            expand=True,
            padx=12,
            pady=(0, 8)
        )

        self.merge_tab = ttk.Frame(self.notebook, padding=14)
        self.fit_tab = ttk.Frame(self.notebook, padding=14)
        self.music_tab = ttk.Frame(self.notebook, padding=14)
        self.speed_tab = ttk.Frame(self.notebook, padding=14)

        self.notebook.add(self.merge_tab, text="Merge Videos")
        self.notebook.add(self.fit_tab, text="Fit Video")
        self.notebook.add(self.music_tab, text="Add Music")
        self.notebook.add(self.speed_tab, text="Change Speed")

        self.build_merge_tab()
        self.build_fit_tab()
        self.build_music_tab()
        self.build_speed_tab()

        self.status = tk.StringVar(
            value="Ready. Select a tool to begin."
        )

        ttk.Label(
            self.root,
            textvariable=self.status,
            anchor="w"
        ).pack(fill="x", padx=14, pady=(0, 10))

    # ---------------- COMMON HELPERS ----------------

    def set_status(self, text):
        self.root.after(0, self.status.set, text)

    def show_error(self, title, error):
        self.root.after(
            0,
            lambda: messagebox.showerror(title, str(error), parent=self.root)
        )

    def show_success(self, output):
        def display():
            messagebox.showinfo(
                "Completed",
                "Video saved successfully!\n\n" + output,
                parent=self.root
            )
            self.status.set("Completed successfully.")

        self.root.after(0, display)

    def start_job(self, title, function):
        if not find_ffmpeg():
            messagebox.showerror(
                "FFmpeg not found",
                "FFmpeg install karo aur uske bin folder ko Windows PATH "
                "mein add karo.\n\nCommand Prompt mein ffmpeg -version "
                "chala kar check karo.",
                parent=self.root
            )
            return

        def worker():
            self.set_status(title + "...")
            try:
                output = function()
                self.show_success(output)
            except Exception as error:
                self.set_status("Operation failed.")
                self.show_error(title + " failed", error)

        threading.Thread(target=worker, daemon=True).start()

    def choose_output(self, title="Save video as"):
        return filedialog.asksaveasfilename(
            parent=self.root,
            title=title,
            defaultextension=".mp4",
            filetypes=[("MP4 Video", "*.mp4")]
        )

    def output_options(self):
        return [
            "-c:v", "libx264",
            "-preset", "veryfast",
            "-crf", "20",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart"
        ]

    # ---------------- MERGE VIDEOS ----------------

    def build_merge_tab(self):
        ttk.Label(
            self.merge_tab,
            text="Videos ko ek MP4 file mein jodo.",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(0, 8))

        self.video_list = tk.Listbox(
            self.merge_tab,
            height=12,
            selectmode=tk.EXTENDED,
            font=("Segoe UI", 9)
        )
        self.video_list.pack(fill="both", expand=True, pady=5)

        buttons = ttk.Frame(self.merge_tab)
        buttons.pack(fill="x", pady=7)

        ttk.Button(
            buttons,
            text="Add Videos",
            command=self.add_videos
        ).pack(side="left", padx=(0, 6))

        ttk.Button(
            buttons,
            text="Remove Selected",
            command=self.remove_videos
        ).pack(side="left", padx=6)

        ttk.Button(
            buttons,
            text="Clear List",
            command=lambda: self.video_list.delete(0, tk.END)
        ).pack(side="left", padx=6)

        ttk.Button(
            self.merge_tab,
            text="MERGE VIDEOS",
            command=self.merge_videos
        ).pack(anchor="e", pady=8)

    def add_videos(self):
        files = filedialog.askopenfilenames(
            parent=self.root,
            title="Select videos",
            filetypes=[
                ("Video files", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v"),
                ("All files", "*.*")
            ]
        )

        existing = set(self.video_list.get(0, tk.END))

        for path in files:
            if path not in existing:
                self.video_list.insert(tk.END, path)

    def remove_videos(self):
        selected = list(self.video_list.curselection())

        for index in reversed(selected):
            self.video_list.delete(index)

    def merge_videos(self):
        videos = list(self.video_list.get(0, tk.END))

        if len(videos) < 2:
            messagebox.showwarning(
                "Select videos",
                "Merge karne ke liye kam se kam 2 videos select karo.",
                parent=self.root
            )
            return

        output = self.choose_output("Save merged video")

        if not output:
            return

        if any(os.path.abspath(v) == os.path.abspath(output) for v in videos):
            messagebox.showerror(
                "Invalid output",
                "Output file ko input video se alag rakho.",
                parent=self.root
            )
            return

        self.start_job(
            "Merging videos",
            lambda: self._merge_worker(videos, output)
        )

    def _merge_worker(self, videos, output):
        # Each clip is converted to the same format before joining.
        # This also handles different input resolutions and missing audio.
        with tempfile.TemporaryDirectory(prefix="offline_merge_") as temp:
            segments = []

            for index, video in enumerate(videos):
                self.set_status(
                    f"Preparing video {index + 1} of {len(videos)}..."
                )

                segment = os.path.join(
                    temp, f"segment_{index:04d}.mp4"
                )

                command = [
                    find_ffmpeg(), "-y",
                    "-i", video
                ]

                if not has_audio(video):
                    command += [
                        "-f", "lavfi",
                        "-i", "anullsrc=channel_layout=stereo:sample_rate=44100"
                    ]
                    audio_map = ["-map", "1:a:0"]
                    shortest = ["-shortest"]
                else:
                    audio_map = ["-map", "0:a:0?"]
                    shortest = []

                command += [
                    "-map", "0:v:0",
                    *audio_map,
                    "-vf",
                    "scale=1080:1920:force_original_aspect_ratio=decrease,"
                    "pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black,"
                    "setsar=1,fps=30",
                    "-ar", "44100",
                    *shortest,
                    *self.output_options(),
                    segment
                ]

                run_command(command)
                segments.append(segment)

            self.set_status("Joining prepared videos...")

            # Escape special characters in paths for FFmpeg concat files.
            list_file = os.path.join(temp, "list.txt")

            with open(list_file, "w", encoding="utf-8", newline="\n") as file:
                for segment in segments:
                    safe_path = os.path.abspath(segment).replace("\\", "/")
                    safe_path = safe_path.replace("'", "'\\''")
                    file.write("file '" + safe_path + "'\n")

            run_command([
                find_ffmpeg(), "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", list_file,
                *self.output_options(),
                output
            ])

        return output

    # ---------------- FIT VIDEO WITHOUT CROPPING ----------------

    def build_fit_tab(self):
        ttk.Label(
            self.fit_tab,
            text="Poora video frame mein fit karo.",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(0, 5))

        ttk.Label(
            self.fit_tab,
            text=(
                "Fit mode video ke sides nahi kaatega. Zarurat padne par "
                "black bars aayengi, taaki poori video dikh sake."
            ),
            wraplength=680
        ).pack(anchor="w", pady=(0, 12))

        self.fit_input = tk.StringVar()
        self.fit_ratio = tk.StringVar(value="9:16 Shorts")

        ttk.Label(self.fit_tab, text="Input video").pack(anchor="w")

        row = ttk.Frame(self.fit_tab)
        row.pack(fill="x", pady=(3, 12))

        ttk.Entry(
            row,
            textvariable=self.fit_input
        ).pack(side="left", fill="x", expand=True)

        ttk.Button(
            row,
            text="Browse",
            command=self.browse_fit
        ).pack(side="left", padx=(8, 0))

        ttk.Label(self.fit_tab, text="Output format").pack(anchor="w")

        ttk.Combobox(
            self.fit_tab,
            textvariable=self.fit_ratio,
            values=[
                "9:16 Shorts",
                "1:1 Square",
                "16:9 Landscape"
            ],
            state="readonly"
        ).pack(anchor="w", fill="x", pady=(3, 14))

        ttk.Button(
            self.fit_tab,
            text="FIT VIDEO AND SAVE",
            command=self.fit_video
        ).pack(anchor="e", pady=8)

    def browse_fit(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Choose video",
            filetypes=[("Video files", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v")]
        )

        if path:
            self.fit_input.set(path)

    def fit_video(self):
        source = self.fit_input.get().strip()

        if not os.path.isfile(source):
            messagebox.showwarning(
                "Choose video",
                "Pehle valid input video select karo.",
                parent=self.root
            )
            return

        output = self.choose_output("Save fitted video")

        if not output:
            return

        if os.path.abspath(source) == os.path.abspath(output):
            messagebox.showerror(
                "Invalid output",
                "Output file ka naam alag rakho.",
                parent=self.root
            )
            return

        ratio = self.fit_ratio.get()

        dimensions = {
            "9:16 Shorts": (1080, 1920),
            "1:1 Square": (1080, 1080),
            "16:9 Landscape": (1920, 1080)
        }

        width, height = dimensions[ratio]

        self.start_job(
            "Fitting video",
            lambda: self._fit_worker(source, output, width, height)
        )

    def _fit_worker(self, source, output, width, height):
        # force_original_aspect_ratio=decrease keeps the whole picture.
        # pad fills the remaining space instead of cropping the edges.
        vf = (
            f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
            f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black,"
            "setsar=1"
        )

        command = [
            find_ffmpeg(), "-y",
            "-i", source,
            "-map", "0:v:0",
            "-map", "0:a:0?",
            "-vf", vf,
            *self.output_options(),
            output
        ]

        run_command(command)
        return output

    # ---------------- ADD BACKGROUND MUSIC ----------------

    def build_music_tab(self):
        ttk.Label(
            self.music_tab,
            text="Video mein background music add karo.",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(0, 12))

        self.music_video = tk.StringVar()
        self.music_file = tk.StringVar()

        self.add_file_row(
            self.music_tab,
            "Input video",
            self.music_video,
            self.browse_music_video
        )

        self.add_file_row(
            self.music_tab,
            "Music file",
            self.music_file,
            self.browse_music_file
        )

        self.music_volume = tk.DoubleVar(value=0.25)
        self.keep_original = tk.BooleanVar(value=True)

        ttk.Label(
            self.music_tab,
            text="Background music volume"
        ).pack(anchor="w", pady=(12, 2))

        ttk.Scale(
            self.music_tab,
            from_=0.0,
            to=1.0,
            variable=self.music_volume,
            orient="horizontal"
        ).pack(fill="x", pady=4)

        self.music_volume_label = ttk.Label(
            self.music_tab,
            text="25%"
        )
        self.music_volume_label.pack(anchor="e")

        self.music_volume.trace_add(
            "write",
            self.update_music_volume_label
        )

        ttk.Checkbutton(
            self.music_tab,
            text="Original video audio bhi rakho",
            variable=self.keep_original
        ).pack(anchor="w", pady=8)

        ttk.Button(
            self.music_tab,
            text="ADD MUSIC AND SAVE",
            command=self.add_music
        ).pack(anchor="e", pady=10)

    def add_file_row(self, parent, label, variable, callback):
        ttk.Label(parent, text=label).pack(anchor="w")

        row = ttk.Frame(parent)
        row.pack(fill="x", pady=(3, 10))

        ttk.Entry(
            row,
            textvariable=variable
        ).pack(side="left", fill="x", expand=True)

        ttk.Button(
            row,
            text="Browse",
            command=callback
        ).pack(side="left", padx=(8, 0))

    def update_music_volume_label(self, *_):
        self.music_volume_label.config(
            text=f"{int(self.music_volume.get() * 100)}%"
        )

    def browse_music_video(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Choose video",
            filetypes=[("Video files", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v")]
        )

        if path:
            self.music_video.set(path)

    def browse_music_file(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Choose music",
            filetypes=[
                ("Audio files", "*.mp3 *.wav *.m4a *.aac *.flac *.ogg"),
                ("All files", "*.*")
            ]
        )

        if path:
            self.music_file.set(path)

    def add_music(self):
        source = self.music_video.get().strip()
        music = self.music_file.get().strip()

        if not os.path.isfile(source) or not os.path.isfile(music):
            messagebox.showwarning(
                "Select files",
                "Input video aur music file dono select karo.",
                parent=self.root
            )
            return

        output = self.choose_output("Save video with music")

        if not output:
            return

        if os.path.abspath(source) == os.path.abspath(output):
            messagebox.showerror(
                "Invalid output",
                "Output file ka naam alag rakho.",
                parent=self.root
            )
            return

        volume = max(0.0, min(1.0, self.music_volume.get()))
        keep = self.keep_original.get()

        self.start_job(
            "Adding background music",
            lambda: self._music_worker(
                source, music, output, volume, keep
            )
        )

    def _music_worker(self, source, music, output, volume, keep):
        original_has_audio = has_audio(source)

        command = [
            find_ffmpeg(), "-y",
            "-i", source,
            "-stream_loop", "-1",
            "-i", music
        ]

        if keep and original_has_audio:
            # Lower original audio slightly and mix with background music.
            filter_complex = (
                "[0:a:0]volume=0.8[original];"
                f"[1:a:0]volume={volume:.3f}[background];"
                "[original][background]amix=inputs=2:duration=first:"
                "dropout_transition=2[aout]"
            )

            command += [
                "-filter_complex", filter_complex,
                "-map", "0:v:0",
                "-map", "[aout]"
            ]

        else:
            command += [
                "-map", "0:v:0",
                "-map", "1:a:0",
                "-af", f"volume={volume:.3f}"
            ]

        command += [
            "-shortest",
            *self.output_options(),
            output
        ]

        run_command(command)
        return output

    # ---------------- CHANGE VIDEO SPEED ----------------

    def build_speed_tab(self):
        ttk.Label(
            self.speed_tab,
            text="Video ki playback speed badlo.",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(0, 12))

        self.speed_video = tk.StringVar()
        self.speed_value = tk.DoubleVar(value=1.0)

        self.add_file_row(
            self.speed_tab,
            "Input video",
            self.speed_video,
            self.browse_speed_video
        )

        ttk.Label(
            self.speed_tab,
            text="Speed: 1x se 2.5x"
        ).pack(anchor="w", pady=(12, 3))

        ttk.Scale(
            self.speed_tab,
            from_=1.0,
            to=2.5,
            variable=self.speed_value,
            orient="horizontal"
        ).pack(fill="x", pady=5)

        self.speed_label = ttk.Label(
            self.speed_tab,
            text="1.00x"
        )
        self.speed_label.pack(anchor="e")

        self.speed_value.trace_add(
            "write",
            self.update_speed_label
        )

        ttk.Button(
            self.speed_tab,
            text="CHANGE SPEED AND SAVE",
            command=self.change_speed
        ).pack(anchor="e", pady=18)

    def update_speed_label(self, *_):
        self.speed_label.config(
            text=f"{self.speed_value.get():.2f}x"
        )

    def browse_speed_video(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Choose video",
            filetypes=[("Video files", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v")]
        )

        if path:
            self.speed_video.set(path)

    def change_speed(self):
        source = self.speed_video.get().strip()

        if not os.path.isfile(source):
            messagebox.showwarning(
                "Choose video",
                "Pehle valid video select karo.",
                parent=self.root
            )
            return

        speed = round(self.speed_value.get(), 2)

        output = self.choose_output("Save speed-adjusted video")

        if not output:
            return

        if os.path.abspath(source) == os.path.abspath(output):
            messagebox.showerror(
                "Invalid output",
                "Output file ka naam alag rakho.",
                parent=self.root
            )
            return

        self.start_job(
            "Changing speed",
            lambda: self._speed_worker(source, output, speed)
        )

    def _speed_worker(self, source, output, speed):
        vf = f"setpts=PTS/{speed:.6f}"

        command = [
            find_ffmpeg(), "-y",
            "-i", source,
            "-map", "0:v:0",
            "-vf", vf,
            "-map", "0:a:0?"
        ]

        if has_audio(source):
            command += [
                "-af", audio_speed_filter(speed)
            ]

        command += [
            *self.output_options(),
            output
        ]

        run_command(command)
        return output


if __name__ == "__main__":
    app = App()
    app.root.mainloop()
